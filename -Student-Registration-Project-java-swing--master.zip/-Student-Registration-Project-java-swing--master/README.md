
![1 login](https://user-images.githubusercontent.com/37055246/81795668-fd0e6c00-9529-11ea-9e09-3651ca808cd3.PNG)



![2 dashboard](https://user-images.githubusercontent.com/37055246/81795973-6c845b80-952a-11ea-848d-1a36410a5e75.PNG)


![3 ad std](https://user-images.githubusercontent.com/37055246/81796381-ffbd9100-952a-11ea-8a9d-b1151a14e344.PNG)



![4 add admin](https://user-images.githubusercontent.com/37055246/81796514-2976b800-952b-11ea-998c-9acf0aebae21.PNG)



![5 up admin](https://user-images.githubusercontent.com/37055246/81796561-3bf0f180-952b-11ea-8032-74a086215f09.PNG)



![6 up std](https://user-images.githubusercontent.com/37055246/81796632-56c36600-952b-11ea-9502-7ff6423875e2.PNG)



![7 show std](https://user-images.githubusercontent.com/37055246/81796822-97bb7a80-952b-11ea-88e3-80697a1dad5d.PNG)
